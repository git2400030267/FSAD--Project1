package com.example.fsd_17_dec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fsd17DecApplication {

	public static void main(String[] args) {
		SpringApplication.run(Fsd17DecApplication.class, args);
	}

}
