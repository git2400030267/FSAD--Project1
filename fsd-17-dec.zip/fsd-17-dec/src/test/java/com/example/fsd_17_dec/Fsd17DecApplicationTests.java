package com.example.fsd_17_dec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fsd17DecApplicationTests {

	@Test
	void contextLoads() {
	}

}
